package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LogProducerApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(LogProducerApiApplication.class, args);
	}

}
